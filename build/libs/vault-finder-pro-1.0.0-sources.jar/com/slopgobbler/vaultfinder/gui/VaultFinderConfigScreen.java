package com.slopgobbler.vaultfinder.gui;

import com.slopgobbler.vaultfinder.config.VaultFinderConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * In-game configuration screen for VaultFinder Pro, integrated with ModMenu.
 */
@Environment(EnvType.CLIENT)
public class VaultFinderConfigScreen extends class_437 {

    private final class_437 parent;
    private final VaultFinderConfig config;

    private static final int[] RANGE_PRESETS = new int[]{16, 32, 64, 96, 128, 192, 256};

    public VaultFinderConfigScreen(class_437 parent) {
        super(class_2561.method_43470("VaultFinder Pro Settings"));
        this.parent = parent;
        this.config = VaultFinderConfig.get();
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int startY = 55;
        int buttonWidth = 220;
        int buttonHeight = 20;
        int spacing = 24;

        // 1. 3D Radar Toggle
        method_37063(class_4185.method_46430(
                getRadarText(),
                button -> {
                    config.setRadarEnabled(!config.isRadarEnabled());
                    button.method_25355(getRadarText());
                }
        ).method_46434(centerX - buttonWidth / 2, startY, buttonWidth, buttonHeight).method_46431());

        // 2. Shulker Peek Toggle
        method_37063(class_4185.method_46430(
                getShulkerPeekText(),
                button -> {
                    config.setShulkerPeekEnabled(!config.isShulkerPeekEnabled());
                    button.method_25355(getShulkerPeekText());
                }
        ).method_46434(centerX - buttonWidth / 2, startY + spacing, buttonWidth, buttonHeight).method_46431());

        // 3. X-Ray Through Blocks Toggle
        method_37063(class_4185.method_46430(
                getXrayText(),
                button -> {
                    config.setXrayEnabled(!config.isXrayEnabled());
                    button.method_25355(getXrayText());
                }
        ).method_46434(centerX - buttonWidth / 2, startY + spacing * 2, buttonWidth, buttonHeight).method_46431());

        // 4. Highlighting Range Cycle
        method_37063(class_4185.method_46430(
                getRangeText(),
                button -> {
                    cycleRange();
                    button.method_25355(getRangeText());
                }
        ).method_46434(centerX - buttonWidth / 2, startY + spacing * 3, buttonWidth, buttonHeight).method_46431());

        // 5. Match Colors Cycle (Spring Green / Bright Yellow)
        method_37063(class_4185.method_46430(
                getColorsText(),
                button -> {
                    cycleColors();
                    button.method_25355(getColorsText());
                }
        ).method_46434(centerX - buttonWidth / 2, startY + spacing * 4, buttonWidth, buttonHeight).method_46431());

        // 6. Reset Defaults
        method_37063(class_4185.method_46430(
                class_2561.method_43470("Reset to Defaults"),
                button -> {
                    config.setHighlightRange(VaultFinderConfig.DEFAULT_RANGE);
                    config.setRadarEnabled(true);
                    config.setShulkerPeekEnabled(true);
                    config.setXrayEnabled(true);
                    config.setMatchingColor(VaultFinderConfig.DEFAULT_MATCHING_COLOR);
                    config.setPartialMatchingColor(VaultFinderConfig.DEFAULT_PARTIAL_COLOR);
                    config.save();
                    this.method_41843();
                }
        ).method_46434(centerX - buttonWidth / 2, startY + spacing * 5 + 10, buttonWidth, buttonHeight).method_46431());

        // 7. Done Button
        method_37063(class_4185.method_46430(
                class_2561.method_43470("Done"),
                button -> method_25419()
        ).method_46434(centerX - 100, this.field_22790 - 32, 200, 20).method_46431());
    }

    private class_2561 getRadarText() {
        return class_2561.method_43470("3D Container Radar: " + (config.isRadarEnabled() ? "§aEnabled" : "§cDisabled"));
    }

    private class_2561 getShulkerPeekText() {
        return class_2561.method_43470("Shulker Box Peek: " + (config.isShulkerPeekEnabled() ? "§aEnabled" : "§cDisabled"));
    }

    private class_2561 getXrayText() {
        return class_2561.method_43470("X-Ray Through Walls: " + (config.isXrayEnabled() ? "§aEnabled" : "§cDisabled"));
    }

    private class_2561 getRangeText() {
        return class_2561.method_43470("Radar Range: §e" + config.getHighlightRange() + " blocks");
    }

    private class_2561 getColorsText() {
        return class_2561.method_43470("Match Colors: §aFull §7/ §ePartial");
    }

    private void cycleRange() {
        int current = config.getHighlightRange();
        int next = RANGE_PRESETS[0];
        for (int i = 0; i < RANGE_PRESETS.length; i++) {
            if (RANGE_PRESETS[i] == current) {
                next = RANGE_PRESETS[(i + 1) % RANGE_PRESETS.length];
                break;
            } else if (RANGE_PRESETS[i] > current) {
                next = RANGE_PRESETS[i];
                break;
            }
        }
        config.setHighlightRange(next);
    }

    private void cycleColors() {
        if (config.getMatchingColor() == VaultFinderConfig.DEFAULT_MATCHING_COLOR) {
            config.setMatchingColor(0xFF00E5FF);       // Cyan
            config.setPartialMatchingColor(0xFFFF8800); // Orange
        } else {
            config.setMatchingColor(VaultFinderConfig.DEFAULT_MATCHING_COLOR);
            config.setPartialMatchingColor(VaultFinderConfig.DEFAULT_PARTIAL_COLOR);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_27534(
                this.field_22793,
                this.field_22785,
                this.field_22789 / 2,
                18,
                0xFFFFFF
        );

        context.method_27534(
                this.field_22793,
                class_2561.method_43470("§7Client-side container cache & radar configuration"),
                this.field_22789 / 2,
                34,
                0xAAAAAA
        );
    }

    @Override
    public void method_25419() {
        config.save();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }
}
